# Banking-Management-System
Admin username  = admin

Admin password   = adm123

I will create this system using C Language. I  store data using File handling.
Admin can loging using this username and password. if he adds a customer and create customer account then customer also can login to this
system through the user name and password which gives when  create customer account.
